<?php

namespace App\Http\Controllers;

use App\Models\Profile;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class PublicProfileController extends Controller
{
    /**
     * Display the public profile edit form.
     */
    public function edit(Request $request): View
    {
        return view('public-profile.edit', [
            'user' => $request->user(),
            'profile' => $request->user()->profile,
        ]);
    }

    /**
     * Update the user's public profile.
     */
    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'tradition' => ['nullable', 'string', 'max:255'],
            'bio' => ['nullable', 'string', 'max:2000'],
            'city' => ['nullable', 'string', 'max:255'],
            'state_province' => ['nullable', 'string', 'max:2'],
            'country' => ['nullable', 'in:US,CA'],
            'website' => ['nullable', 'url', 'max:255'],
            'facebook_url' => ['nullable', 'url', 'max:255'],
            'instagram_url' => ['nullable', 'url', 'max:255'],
            'x_url' => ['nullable', 'url', 'max:255'],
            'public_email' => ['nullable', 'email', 'max:255'],
            'phone_number' => ['nullable', 'string', 'max:50'],
            'is_public' => ['boolean'],
            'clergy' => ['nullable', 'boolean'],
            'avatar' => ['nullable', 'image', 'max:2048'],
        ], [
            'avatar.uploaded' => 'The profile photo failed to upload. It may be larger than the server allows (maximum 2MB) or an unsupported file type.',
            'avatar.max' => 'The profile photo must not be larger than 2MB.',
            'avatar.image' => 'The profile photo must be an image file (JPG, PNG, GIF, etc).',
        ]);

        // Convert empty strings to null so cleared fields write null to the DB, not ""
        $validated = array_map(fn($v) => $v === '' ? null : $v, $validated);

        // Radio buttons submit '1' or '0' as strings; cast to boolean and default to false if missing
        $validated['clergy'] = (bool) ($validated['clergy'] ?? false);

        // Unchecked checkboxes send nothing — explicitly default to false so the column is always updated
        $validated['is_public'] = (bool) ($validated['is_public'] ?? false);

        // "Don't Show Location" — if country is blank, null all three location fields in the DB
        if (empty($validated['country'])) {
            $validated['country'] = null;
            $validated['state_province'] = null;
            $validated['city'] = null;
        }


        // Handle avatar upload
        if ($request->hasFile('avatar')) {
            $profile = $request->user()->profile;

            // Delete old avatar if one exists
            if ($profile?->avatar_path) {
                Storage::disk('public')->delete($profile->avatar_path);
            }

            $validated['avatar_path'] = $request->file('avatar')->store('avatars', 'public');
        }

        // Remove the raw file key — only avatar_path is stored in the DB
        unset($validated['avatar']);

        $request->user()->profile()->updateOrCreate(
            ['user_id' => $request->user()->id],
            $validated
        );

        return redirect()->route('public-profile.edit')
            ->with('status', 'public-profile-updated');
    }

    /**
     * Display the public profile of a practitioner.
     */
    public function show(Profile $profile): View
    {
        // Security: Only allow viewing public profiles
        if (!$profile->is_public) {
            abort(404);
        }

        // Load the user relationship
        $profile->load('user');

        // Map of country codes to full names for display
        $countryNames = [
            'US' => 'United States',
            'CA' => 'Canada',
        ];

        return view('public-profile.show', [
            'profile' => $profile,
            'countryNames' => $countryNames,
        ]);
    }
}
